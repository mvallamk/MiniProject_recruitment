package com.cg.entities;

public class CandidatePersonal 
{
	
}
